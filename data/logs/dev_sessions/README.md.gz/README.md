# Development Session Logs

This directory contains compressed logs and transcripts of development sessions, including interactions with GitHub Copilot and collaborators. These logs provide a detailed record of the project’s evolution and are referenced in DEVELOPMENT_HISTORY.md.

- Use GitHub LFS for large files.
- Reference specific logs in documentation or JOSS submission as needed.
